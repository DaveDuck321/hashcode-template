#!/bin/bash
mkdir -p submission
touch max.json
zip submission/src.zip *.py solvers/*.py max.json

